var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/target-university/route.js")
R.c("server/chunks/[externals]_next_dist_a6d89067._.js")
R.c("server/chunks/fb9f4_1f250bc9._.js")
R.c("server/chunks/[root-of-the-server]__3f765262._.js")
R.c("server/chunks/b5985__next-internal_server_app_api_target-university_route_actions_1bac4ec7.js")
R.m(15086)
module.exports=R.m(15086).exports
