var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__3f765262._.js")
R.c("server/chunks/fb9f4_next_dist_esm_build_templates_app-route_4abd0d0c.js")
R.c("server/chunks/be5c9_platform-utbk__next-internal_server_app_favicon_ico_route_actions_6b9e447e.js")
R.m(76026)
module.exports=R.m(76026).exports
