module.exports=[59296,(e,o,d)=>{}];

//# sourceMappingURL=b5985__next-internal_server_app_api_target-university_route_actions_1bac4ec7.js.map