module.exports=[25063,(e,o,d)=>{}];

//# sourceMappingURL=be5c9_platform-utbk__next-internal_server_app_favicon_ico_route_actions_6b9e447e.js.map