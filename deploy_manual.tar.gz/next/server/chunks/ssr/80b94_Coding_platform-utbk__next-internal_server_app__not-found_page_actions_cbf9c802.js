module.exports=[14965,(a,b,c)=>{}];

//# sourceMappingURL=80b94_Coding_platform-utbk__next-internal_server_app__not-found_page_actions_cbf9c802.js.map