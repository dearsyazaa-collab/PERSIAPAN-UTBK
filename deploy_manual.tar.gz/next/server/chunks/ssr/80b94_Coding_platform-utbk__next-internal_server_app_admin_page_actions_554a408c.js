module.exports=[55035,(a,b,c)=>{}];

//# sourceMappingURL=80b94_Coding_platform-utbk__next-internal_server_app_admin_page_actions_554a408c.js.map