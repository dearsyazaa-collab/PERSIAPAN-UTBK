module.exports=[14970,(a,b,c)=>{}];

//# sourceMappingURL=80b94_Coding_platform-utbk__next-internal_server_app_bank-soal_page_actions_0bab20d7.js.map