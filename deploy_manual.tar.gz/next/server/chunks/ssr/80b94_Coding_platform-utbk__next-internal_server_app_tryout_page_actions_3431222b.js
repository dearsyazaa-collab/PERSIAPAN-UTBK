module.exports=[635,(a,b,c)=>{}];

//# sourceMappingURL=80b94_Coding_platform-utbk__next-internal_server_app_tryout_page_actions_3431222b.js.map