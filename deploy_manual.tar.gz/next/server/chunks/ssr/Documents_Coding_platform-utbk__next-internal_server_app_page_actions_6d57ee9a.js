module.exports=[32727,(a,b,c)=>{}];

//# sourceMappingURL=Documents_Coding_platform-utbk__next-internal_server_app_page_actions_6d57ee9a.js.map