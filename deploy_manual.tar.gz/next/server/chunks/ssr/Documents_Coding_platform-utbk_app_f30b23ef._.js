module.exports=[72438,a=>{a.v("/_next/static/media/favicon.dcb4de73.ico")},72274,a=>{"use strict";let b={src:a.i(72438).default,width:512,height:512};a.s(["default",0,b])}];

//# sourceMappingURL=Documents_Coding_platform-utbk_app_f30b23ef._.js.map