module.exports=[4917,(a,b,c)=>{}];

//# sourceMappingURL=b5985__next-internal_server_app_admin_kelola%20soal_%5Bid%5D_page_actions_c725a497.js.map