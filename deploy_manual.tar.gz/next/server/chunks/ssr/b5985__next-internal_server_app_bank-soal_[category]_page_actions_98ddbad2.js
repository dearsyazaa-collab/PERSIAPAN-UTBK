module.exports=[12427,(a,b,c)=>{}];

//# sourceMappingURL=b5985__next-internal_server_app_bank-soal_%5Bcategory%5D_page_actions_98ddbad2.js.map