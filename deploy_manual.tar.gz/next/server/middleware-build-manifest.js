globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/e6b124cea10fbff1.js",
    "static/chunks/15ccfa5845cc57a7.js",
    "static/chunks/4108e5ce72d9ee81.js",
    "static/chunks/7fa5fa5e88086b32.js",
    "static/chunks/a11c490fde83cbbd.js",
    "static/chunks/turbopack-8543dc551e7026f8.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];